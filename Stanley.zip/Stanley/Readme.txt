Thanks for downloading this template!

Template Name: Stanley
Template URL: https://templatemag.com/stanley-bootstrap-freelancer-template/
Author: TemplateMag.com
License: https://templatemag.com/license/